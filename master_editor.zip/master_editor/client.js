const net = require('net');

const client = new net.Socket();
client.connect(4000, '127.0.0.1', () => {
  console.log('Connected to server');
  client.write('Hello from Node.js client!');
});

client.on('data', (data) => {
  console.log('Received from server: ' + data.toString());
  client.destroy(); // Close connection after response
});

client.on('close', () => {
  console.log('Connection closed');
});
